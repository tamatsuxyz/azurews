Configuration SetupWebServer
{
    param 
    ( 
        [Int]$RetryCount = 5,
        [Int]$RetryIntervalSec = 30
    ) 

    Import-DSCResource -ModuleName PSDesiredStateConfiguration, ComputerManagementDsc

    Node localhost
    {
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ActionAfterReboot  = 'ContinueConfiguration'
            #ConfigurationMode  = 'ApplyAndAutoCorrect'
        }

        TimeZone TimeZone {
            IsSingleInstance = 'Yes'
            TimeZone         = 'Tokyo Standard Time'
        }
        
        WindowsFeature IIS { 
            Ensure    = 'Present' 
            Name      = 'Web-Server'
            IncludeAllSubFeature = $True
        }
    }

}   